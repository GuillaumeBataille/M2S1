The code for the viewer was inspired from "gMini", provided by Pr. Tamy Boubekeur at : http://perso.telecom-paristech.fr/~boubek/#code
